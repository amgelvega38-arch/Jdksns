# Acceso visible a FF MORMAL

- Se añadió un botón fijo y visible `FF MORMAL` alineado a la esquina superior derecha, debajo de la fila del encabezado.
- Al tocarlo, selecciona directamente la sección `FF MORMAL`, mostrando sus opciones `HOLO AR` y `HOLOGRAMA`.
- Se retiró `FF MORMAL` de la tira horizontal desplazable para evitar que quede oculto fuera de pantalla.
- Se conservan los controladores independientes de activar/desactivar de ambos paquetes.
- No se modificó el contenido ni el formato de los paquetes `.3105`.

Validación: se verificó el cambio en el código Swift y la presencia de los recursos en el proyecto. La compilación y la prueba en dispositivo requieren Xcode/iPhone.
