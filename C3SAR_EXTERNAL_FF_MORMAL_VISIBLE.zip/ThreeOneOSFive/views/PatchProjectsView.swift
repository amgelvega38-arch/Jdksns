import SwiftUI
import UIKit
import UniformTypeIdentifiers

private enum PatchPackagePickerPolicy {
    static let packageType = UTType(filenameExtension: "3105") ?? .data
    static let allowedContentTypes: [UTType] = [packageType, .data]
    static let copiesSelectedDocument = true
}

struct PatchProjectsView: View {
    let ghostTheme: Bool
    @Environment(\.appLanguage) private var language
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @EnvironmentObject private var draftCoordinator: PatchDraftCoordinator
    @StateObject private var store = PatchProjectStore()
    @EnvironmentObject private var pantherSession: PantherSession
    @State private var countdownNow = Date()
    private let countdownTimer = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()
    private var keyCountdown: String {
        if pantherSession.permanent { return "Acceso permanente" }
        guard let expires = pantherSession.expiresAt else { return "Verificando key..." }
        let remaining = max(0, expires.timeIntervalSince(countdownNow))
        let seconds = Int(remaining)
        let days = seconds / 86400
        let hours = (seconds % 86400) / 3600
        let secs = seconds % 60
        let millis = Int((remaining - Double(seconds)) * 1000)
        return String(format: "%dd %02dh %02ds %03dms", days, hours, secs, millis)
    }
    @State private var showCreate = false
    @State private var showImporter = false
    @State private var searchText = ""
    @State private var busyPatchIDs: Set<UUID> = []
    @State private var patchActionMessage: String?
    @State private var patchRefreshToken = 0
    @State private var selectedExternalSection = "AIMBOT"
    @State private var hologramaBusy = false
    @State private var hologramaIsActive = false
    @State private var holoAzulBusy = false
    @State private var holoAzulIsActive = false
    @State private var holoPJAmarilloBusy = false
    @State private var holoPJAmarilloIsActive = false
    @State private var resetFFHBusy = false
    @State private var resetFFHIsActive = false
    @State private var holoARBusy = false
    @State private var holoARIsActive = false
    @State private var hologramaExtraBusy = false
    @State private var hologramaExtraIsActive = false
    @State private var showExternalSettings = false
    @State private var readyPulse = false
    @State private var welcomeAudioPlayed = false
    @AppStorage("externalThemeColor") private var externalThemeColor = "AZUL"

    private var externalAccent: Color { ExternalPalette.color(named: externalThemeColor) }

    // Orden fijo de arriba hacia abajo, independiente del estado de activación.
    private func avatarRank(_ name: String) -> Int {
        switch name.lowercased().trimmingCharacters(in: .whitespacesAndNewlines) {
        case "head avatar": return 0
        case "cuello avatar": return 1
        case "pecho avatar", "pecho alto + cuello avatar": return 2
        case "sintura avatar": return 3
        default: return 4
        }
    }

    private var orderedAvatarItems: [PatchLibraryItem] {
        store.items.filter { item in
            let name = item.project?.name ?? item.packageURL.deletingPathExtension().lastPathComponent
            return avatarRank(name) < 4
        }.sorted { left, right in
            let a = left.project?.name ?? left.packageURL.deletingPathExtension().lastPathComponent
            let b = right.project?.name ?? right.packageURL.deletingPathExtension().lastPathComponent
            if avatarRank(a) != avatarRank(b) { return avatarRank(a) < avatarRank(b) }
            return left.id.uuidString < right.id.uuidString
        }
    }

    private var orderedPublishedPatches: [PantherPatch] {
        pantherSession.publishedPatches.sorted { left, right in
            let a = avatarRank(left.name)
            let b = avatarRank(right.name)
            if a != b { return a < b }
            let nameOrder = left.name.localizedStandardCompare(right.name)
            if nameOrder != .orderedSame { return nameOrder == .orderedAscending }
            return left.id < right.id
        }
    }

    private var filteredItems: [PatchLibraryItem] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return store.items }
        return store.items.filter { item in
            if item.packageURL.lastPathComponent.localizedCaseInsensitiveContains(query) {
                return true
            }
            guard let project = item.project else { return false }
            return project.name.localizedCaseInsensitiveContains(query)
                || project.allBundleIdentifiers.contains {
                    $0.localizedCaseInsensitiveContains(query)
                }
                || project.directories.contains {
                    $0.relativePath.localizedCaseInsensitiveContains(query)
                }
                || project.rules.contains {
                    $0.relativePath.localizedCaseInsensitiveContains(query)
                        || $0.replacementFilename.localizedCaseInsensitiveContains(query)
                }
        }
    }

    init(ghostTheme: Bool = true) {
        self.ghostTheme = true // Pantalla neon para todas las entradas de Patches
#if targetEnvironment(simulator)
        _showCreate = State(
            initialValue: ProcessInfo.processInfo.arguments.contains("--simulate-patch-editor")
        )
#endif
    }

    var body: some View {
        NavigationStack {
            if ghostTheme {
                neonPatchScreen
                .ignoresSafeArea(.container, edges: .all)
            } else {
            VStack(spacing: 0) {
                AppSearchField(
                    text: $searchText,
                    prompt: language.text("patch.search"),
                    clearLabel: language.text("common.clear")
                )
                Divider()
                List {
                    if store.items.isEmpty && !store.isBusy {
                        emptyState
                            .listRowSeparator(.hidden)
                    } else if filteredItems.isEmpty && !store.isBusy {
                        searchEmptyState
                            .listRowSeparator(.hidden)
                    } else {
                        ForEach(filteredItems) { item in
                            itemRow(item)
                        }
                        .onDelete { offsets in
                            offsets.map { filteredItems[$0] }.forEach(store.delete)
                        }
                    }
                }
                .listStyle(.insetGrouped)
                .scrollContentBackground(ghostTheme ? .hidden : .visible)
                .background(ghostTheme ? Color.black.opacity(0.38) : Color.clear)
            }
            .background {
                if ghostTheme {
                    GeometryReader { geometry in
                        Image("ExternalPortraitBackground")
                            .resizable()
                            .scaledToFit()
                            .frame(width: geometry.size.width, height: geometry.size.height)
                            .background(Color.black)
                            .overlay(Color.black.opacity(0.28))
                    }
                    .ignoresSafeArea()
                }
            }
            .navigationTitle(language.text("patch.title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button {
                            showCreate = true
                        } label: {
                            Label(language.text("patch.new"), systemImage: "doc.badge.plus")
                        }
                        Button {
                            showImporter = true
                        } label: {
                            Label(language.text("patch.import"), systemImage: "square.and.arrow.down")
                        }
                    } label: {
                        if store.isBusy {
                            ProgressView()
                        } else {
                            Image(systemName: "plus")
                        }
                    }
                    .disabled(store.isBusy)
                    .accessibilityLabel(language.text("patch.add"))
                }
            }
            .sheet(isPresented: $showImporter) {
                FileDocumentPicker(
                    allowedContentTypes: PatchPackagePickerPolicy.allowedContentTypes,
                    copiesSelectedDocument: PatchPackagePickerPolicy.copiesSelectedDocument,
                    allowsMultipleSelection: false,
                    onSelection: { result in
                        showImporter = false
                        if case .success(let urls) = result, let url = urls.first {
                            store.importPackage(at: url)
                        }
                    },
                    onCancel: {
                        showImporter = false
                    }
                )
                .ignoresSafeArea()
            }
            .sheet(isPresented: $showCreate) {
                PatchProjectEditorView(
                    existingProject: nil,
                    passwordIsProtected: false
                ) { project, password in
                    store.create(project: project, password: password)
                }
            }
            .sheet(item: $draftCoordinator.request) { request in
                PatchProjectEditorView(
                    existingProject: nil,
                    passwordIsProtected: false,
                    initialDraft: request.draft
                ) { project, password in
                    store.create(project: project, password: password)
                    draftCoordinator.clear()
                }
            }
            .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { _ in
                PatchUnlockView(store: store)
            }
            .alert(item: $store.alert) { alert in
                Alert(
                    title: Text(language.text(alert.titleKey)),
                    message: Text(alert.message(language: language)),
                    dismissButton: .default(Text(language.text("common.ok")))
                )
            }
            .onAppear {
                consumeExternalImport()
                Task { await pantherSession.refreshCatalog() }
            }
            .onChange(of: draftCoordinator.importRequest?.id) { _ in
                consumeExternalImport()
            }
            } // original project interface
        }
    }


    private var neonPatchScreen: some View {
        GeometryReader { geometry in
            neonPatchLayout(geometry: geometry)
                .frame(width: geometry.size.width, height: geometry.size.height, alignment: .topLeading)
        }
        .ignoresSafeArea(.container, edges: .all)
        .task {
            while !Task.isCancelled {
                await pantherSession.refreshCatalog()
                try? await Task.sleep(nanoseconds: 30_000_000_000)
            }
        }
        .onReceive(countdownTimer) { now in
            countdownNow = now
            pantherSession.checkExpiry()
        }
        .toolbar(.hidden, for: .navigationBar)
        .statusBarHidden(true)
        .background(Color.black.ignoresSafeArea())
        .alert("Lxz iOS", isPresented: Binding(
            get: { patchActionMessage != nil },
            set: { if !$0 { patchActionMessage = nil } }
        )) {
            Button("Aceptar", role: .cancel) { patchActionMessage = nil }
        } message: {
            Text(patchActionMessage ?? "")
        }
        .onAppear {
            consumeExternalImport()
            importBundledPatchesIfNeeded()
            refreshHologramaStatus()
            refreshResetFFHStatus()
            refreshHoloARStatus()
            refreshHologramaExtraStatus()
            if !welcomeAudioPlayed {
                welcomeAudioPlayed = true
                PantherFeedbackAudio.play("welcome_baby")
            }
        }
        .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { _ in PatchUnlockView(store: store) }
        .sheet(isPresented: $showExternalSettings) { SettingsView() }
        .alert(item: $store.alert) { alert in
            Alert(title: Text(language.text(alert.titleKey)), message: Text(alert.message(language: language)), dismissButton: .default(Text(language.text("common.ok"))))
        }
    }

    private func neonPatchLayout(geometry: GeometryProxy) -> some View {
        ZStack {
            Color.black
            animatedPatchBackground(width: geometry.size.width, height: geometry.size.height)

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    // Header: back button, centered app icon, and settings share one row.
                    HStack(alignment: .center) {
                        Button {
                            pantherSession.signOut()
                        } label: {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 25, weight: .bold))
                                .foregroundStyle(.white)
                                .frame(width: 46, height: 46)
                                .background(Color.black.opacity(0.22), in: Circle())
                        }
                        .buttonStyle(.plain)
                        Spacer(minLength: 0)
                        Link(destination: URL(string: "https://whatsapp.com/channel/0029VbCTB3t9MF98tEHP5a2Y")!) {
                            Image("ExternalPortraitBackground")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 94, height: 82)
                                .clipped()
                                .overlay(alignment: .bottom) {
                                    Text("CANAL OFC")
                                        .font(.system(size: 9, weight: .heavy, design: .rounded))
                                        .tracking(0.8)
                                        .foregroundStyle(.white)
                                        .padding(.vertical, 5)
                                        .frame(maxWidth: .infinity)
                                        .background(Color.black.opacity(0.72))
                                }
                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .stroke(Color.white.opacity(0.48), lineWidth: 1))
                                .shadow(color: .black.opacity(0.25), radius: 10, y: 4)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("CANAL OFC - Abrir canal de WhatsApp")
                        Spacer(minLength: 0)
                        Button { showExternalSettings = true } label: {
                            Image(systemName: "gearshape.fill")
                                .font(.system(size: 25, weight: .semibold))
                                .foregroundStyle(.white)
                                .frame(width: 46, height: 46)
                                .background(Color.black.opacity(0.22), in: Circle())
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.top, max(geometry.safeAreaInsets.top, 58))

                    // Acceso directo, siempre visible en la esquina superior derecha.
                    HStack {
                        Spacer(minLength: 0)
                        Button {
                            withAnimation(.easeInOut(duration: 0.22)) {
                                selectedExternalSection = "FF MORMAL"
                            }
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "sparkles")
                                    .font(.system(size: 13, weight: .black))
                                Text("FF MORMAL")
                                    .font(.system(size: 13, weight: .heavy, design: .rounded))
                                    .tracking(0.8)
                            }
                            .foregroundStyle(.white)
                            .padding(.horizontal, 15)
                            .frame(height: 38)
                            .background(
                                LinearGradient(
                                    colors: [externalAccent.opacity(0.95), Color.cyan.opacity(0.72)],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                ),
                                in: Capsule()
                            )
                            .overlay(Capsule().stroke(Color.white.opacity(0.72), lineWidth: 1))
                            .shadow(color: externalAccent.opacity(0.45), radius: 9, y: 2)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Abrir menú FF MORMAL")
                    }
                    .padding(.top, 9)

                    Text("C3SAR EXTERNAL")
                        .font(.system(size: 18, weight: .heavy, design: .rounded))
                        .tracking(4.2)
                        .foregroundStyle(.white)
                        .padding(.top, 20)

                    Text("Panel De Control")
                        .font(.system(size: min(geometry.size.width * 0.067, 34), weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.72)
                        .padding(.top, 48)

                    HStack(spacing: 9) {
                        Circle().fill(externalAccent).frame(width: 10, height: 10)
                        Text("FREE FIRE MAX")
                            .font(.system(size: 18, weight: .semibold, design: .rounded))
                            .tracking(1.5)
                            .foregroundStyle(externalAccent)
                    }
                    .padding(.top, 22)

                    HStack(spacing: 10) {
                        Circle()
                            .fill(Color.green)
                            .frame(width: 11, height: 11)
                            .opacity(readyPulse ? 1 : 0.22)
                            .shadow(color: .green.opacity(readyPulse ? 0.8 : 0.15), radius: readyPulse ? 8 : 1)
                        Text("System Ready")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundStyle(.white.opacity(0.76))
                        Spacer()
                    }
                    .padding(.top, 62)
                    .onAppear {
                        withAnimation(.easeInOut(duration: 0.85).repeatForever(autoreverses: true)) {
                            readyPulse = true
                        }
                    }

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            externalSectionButton("AIMBOT")
                            externalSectionButton("HOLO ARMA")
                            externalSectionButton("HOLO PJ")
                            externalSectionButton("RESET FFH")
                        }
                    }
                    .padding(.top, 42)
                    .padding(.bottom, 24)

                    if selectedExternalSection == "AIMBOT" {
                        VStack(spacing: 12) {
                            avatarSlot("Pecho Avatar", displayName: "PECHO ALTO + CUELLO AVATAR")
                            ForEach(["Head Avatar", "Cuello Avatar", "Sintura Avatar"], id: \.self) { name in
                                avatarSlot(name)
                            }
                        }
                    } else if selectedExternalSection == "HOLO ARMA" {
                        VStack(spacing: 12) {
                            holoPatchSlot(
                                title: "HOLO ARM RAINBOW",
                                isBusy: hologramaBusy,
                                isActive: hologramaIsActive,
                                action: toggleHologramaAzulAvatar
                            )
                            holoPatchSlot(
                                title: "HOLO ARM AZUL",
                                isBusy: holoAzulBusy,
                                isActive: holoAzulIsActive,
                                action: toggleHoloArmAzul
                            )
                        }
                    } else if selectedExternalSection == "HOLO PJ" {
                        VStack(spacing: 12) {
                            holoPatchSlot(
                                title: "HOLO PJ AMARILLO",
                                isBusy: holoPJAmarilloBusy,
                                isActive: holoPJAmarilloIsActive,
                                action: toggleHoloPJAmarillo
                            )
                        }
                    } else if selectedExternalSection == "RESET FFH" {
                        VStack(spacing: 12) {
                            holoPatchSlot(
                                title: "RESET FFH",
                                isBusy: resetFFHBusy,
                                isActive: resetFFHIsActive,
                                action: toggleResetFFH
                            )
                        }
                    } else if selectedExternalSection == "FF MORMAL" {
                        VStack(spacing: 12) {
                            holoPatchSlot(
                                title: "HOLO AR",
                                isBusy: holoARBusy,
                                isActive: holoARIsActive,
                                action: toggleHoloAR
                            )
                            holoPatchSlot(
                                title: "HOLOGRAMA",
                                isBusy: hologramaExtraBusy,
                                isActive: hologramaExtraIsActive,
                                action: toggleHologramaExtra
                            )
                        }
                    }
                }
                .padding(.horizontal, 22)
                .frame(maxWidth: 560)
                .frame(maxWidth: .infinity)
            }
            // Native scrolling is allowed only within the content bounds: no pull-down
            // overscroll above the header, while swiping up reveals the remaining buttons.
            .modifier(ExternalNoBounceModifier())
        }
        .frame(width: geometry.size.width, height: geometry.size.height)
        .statusBarHidden(true)
    }

    private func openFreeFireMax() {
        // This scheme is a candidate only: Garena has not publicly confirmed it.
        // iOS can open the game only when its installed version registers the scheme.
        guard let gameURL = URL(string: "freefiremax://") else {
            patchActionMessage = "No hay un enlace válido para abrir Free Fire MAX."
            return
        }
        UIApplication.shared.open(gameURL, options: [:]) { didOpen in
            guard !didOpen else { return }
            DispatchQueue.main.async {
                patchActionMessage = "No se pudo abrir Free Fire MAX directamente. El juego puede estar instalado, pero esta versión de iOS o del juego no admite el enlace de apertura."
            }
        }
    }

    private func animatedPatchBackground(width: CGFloat, height: CGFloat) -> some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: reduceMotion)) { timeline in
            let t = timeline.date.timeIntervalSinceReferenceDate
            Image("ExternalPortraitBackground")
                .resizable()
                .scaledToFill()
                .frame(width: width, height: height)
                .clipped()
                .background(Color.black)
                .overlay(Color.black.opacity(0.18))
        }
    }

    private var countdownLabel: some View {
        HStack(spacing: 9) {
            Image(systemName: "key.fill")
                .font(.system(size: 22)).foregroundStyle(externalAccent)
            Text("Key activa")
                .font(.system(size: 14, weight: .bold))
            Rectangle().fill(externalAccent.opacity(0.7)).frame(width: 1, height: 42)
            Image(systemName: "calendar")
                .font(.system(size: 21)).foregroundStyle(externalAccent)
            VStack(alignment: .trailing, spacing: 2) {
                Text("Tiempo restante:").font(.system(size: 13, weight: .bold))
                Text(keyCountdown)
                    .font(.system(size: 13, weight: .bold, design: .monospaced))
                    .foregroundStyle(externalAccent)
                    .lineLimit(1).minimumScaleFactor(0.7)
            }
            Spacer(minLength: 0)
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 12)
        .frame(height: 66)
        .background(Color.black.opacity(0.86), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(externalAccent, lineWidth: 1.5))
    }

    private var onlineCatalogHeader: some View {
        HStack(spacing: 12) {
            Image(systemName: "icloud.and.arrow.down")
                .font(.system(size: 32)).foregroundStyle(externalAccent)
            VStack(alignment: .leading, spacing: 3) {
                Text("CATÁLOGO EN LÍNEA")
                    .font(.system(size: 18, weight: .bold)).foregroundStyle(.white)
                Text("Patches actualizados en tiempo real")
                    .font(.system(size: 11)).foregroundStyle(.white.opacity(0.85))
            }
            Spacer(minLength: 0)
            Button { Task { await pantherSession.refreshCatalog() } } label: {
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 25, weight: .bold))
                    .foregroundStyle(externalAccent)
                    .frame(width: 48, height: 48)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(externalAccent, lineWidth: 2))
            }
        }
        .padding(.horizontal, 14)
        .frame(height: 74)
        .background(Color.black.opacity(0.85), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(externalAccent, lineWidth: 2))
        .shadow(color: externalAccent.opacity(0.4), radius: 6)
    }


    private func externalSectionButton(_ title: String) -> some View {
        let isSelected: Bool = selectedExternalSection == title
        return Button(
            action: {
                withAnimation(.easeInOut(duration: 0.18)) {
                    selectedExternalSection = title
                }
            },
            label: {
                externalSectionButtonLabel(title, isSelected: isSelected)
            }
        )
        .buttonStyle(.plain)
    }

    // Keeping the label in its own small view avoids SwiftUI's type-checking
    // timeout on the long chain of conditional view modifiers above.
    private func externalSectionButtonLabel(_ title: String, isSelected: Bool) -> some View {
        let titleColor: Color = isSelected ? .white : externalAccent
        let fillColor: Color = isSelected ? externalAccent.opacity(0.88) : Color.black.opacity(0.48)
        let borderColor: Color = isSelected ? Color.white.opacity(0.42) : externalAccent.opacity(0.42)
        let glowColor: Color = isSelected ? externalAccent.opacity(0.28) : Color.clear
        let capsule = Capsule()

        return Text(title)
            .font(.system(size: 13, weight: .heavy, design: .rounded))
            .tracking(1.0)
            .foregroundColor(titleColor)
            .padding(.horizontal, 17)
            .frame(height: 42)
            .background(fillColor, in: capsule)
            .overlay(capsule.stroke(borderColor, lineWidth: 1))
            .shadow(color: glowColor, radius: 7)
    }

    private func holoPatchSlot(
        title: String,
        isBusy: Bool,
        isActive: Bool,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: isBusy ? "hourglass" : "sparkles")
                    .font(.system(size: 25, weight: .medium))
                    .foregroundStyle(externalAccent)
                    .frame(width: 40)
                VStack(alignment: .leading, spacing: 5) {
                    Text(isBusy ? "APLICANDO PAQUETE..." : title)
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.72)
                    Text(isActive ? "Aplicado · Toca para desactivar" : "Toca para aplicar el paquete .3105")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(.white.opacity(0.58))
                }
                Spacer(minLength: 4)
                if isBusy {
                    ProgressView().tint(externalAccent).frame(width: 54)
                } else {
                    ZStack(alignment: isActive ? .trailing : .leading) {
                        Capsule().fill(isActive ? externalAccent : Color(white: 0.30)).frame(width: 54, height: 32)
                        Circle().fill(.white).frame(width: 26, height: 26).padding(.horizontal, 3)
                    }
                    .frame(width: 54, height: 32)
                }
            }
            .padding(.horizontal, 16)
            .frame(maxWidth: .infinity)
            .frame(height: 78)
            .background(Color.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 19))
            .overlay(RoundedRectangle(cornerRadius: 19).stroke(externalAccent.opacity(0.62), lineWidth: 1.1))
            .shadow(color: .black.opacity(0.22), radius: 10, y: 4)
        }
        .buttonStyle(.plain)
        .disabled(isBusy)
    }

    private func hologramaPackageURL() -> URL? {
        // Xcode copies individual file references into the app bundle root.
        // Keep the subdirectory fallback for builds that preserve the folder.
        if let url = Bundle.main.url(forResource: "Holograma Rtx", withExtension: "3105"),
           FileManager.default.fileExists(atPath: url.path) {
            return url
        }
        if let url = Bundle.main.url(
            forResource: "Holograma Rtx",
            withExtension: "3105",
            subdirectory: "ProtectedPackages"
        ), FileManager.default.fileExists(atPath: url.path) {
            return url
        }
        if let resourceURL = Bundle.main.resourceURL {
            let url = resourceURL.appendingPathComponent("Holograma Rtx.3105")
            if FileManager.default.fileExists(atPath: url.path) {
                return url
            }
        }
        return nil
    }

    private func refreshHologramaStatus() {
        guard let url = hologramaPackageURL(),
              let data = try? PatchProjectLibrary.readPackage(at: url),
              let summary = try? PatchPackageCodec.inspect(data) else { return }
        hologramaIsActive = DevicePatchService.latestReceipt(projectID: summary.packageID) != nil
        if let azulURL = holoArmAzulPackageURL(),
           let azulData = try? PatchProjectLibrary.readPackage(at: azulURL),
           let azulSummary = try? PatchPackageCodec.inspect(azulData) {
            holoAzulIsActive = DevicePatchService.latestReceipt(projectID: azulSummary.packageID) != nil
        }
        if let amarilloURL = holoPJAmarilloPackageURL(),
           let amarilloData = try? PatchProjectLibrary.readPackage(at: amarilloURL),
           let amarilloSummary = try? PatchPackageCodec.inspect(amarilloData) {
            holoPJAmarilloIsActive = DevicePatchService.latestReceipt(projectID: amarilloSummary.packageID) != nil
        }
    }

    private func toggleHologramaAzulAvatar() {
        guard !hologramaBusy else { return }
        guard let packageURL = hologramaPackageURL() else {
            patchActionMessage = "No se encontró Holograma Rtx.3105 dentro de la app."
            return
        }
        hologramaBusy = true
        Task.detached(priority: .userInitiated) {
            do {
                let data = try PatchProjectLibrary.readPackage(at: packageURL)
                let decoded = try PatchPackageCodec.decode(data, password: nil)
                let receipt = DevicePatchService.latestReceipt(projectID: decoded.project.id)
                if let receipt {
                    try DevicePatchService.restore(receipt: receipt)
                } else {
                    // Rainbow and Azul are alternate variants; restore Azul before switching.
                    if let azulURL = holoArmAzulPackageURL() {
                        let azulData = try PatchProjectLibrary.readPackage(at: azulURL)
                        let azulProject = try PatchPackageCodec.decode(azulData, password: nil).project
                        if let azulReceipt = DevicePatchService.latestReceipt(projectID: azulProject.id) {
                            try DevicePatchService.restore(receipt: azulReceipt)
                        }
                    }
                    _ = try DevicePatchService.apply(project: decoded.project)
                }
                await MainActor.run {
                    hologramaIsActive = (receipt == nil)
                    if receipt == nil { holoAzulIsActive = false }
                    hologramaBusy = false
                    PantherFeedbackAudio.play(receipt == nil ? "opcion_activada" : "opcion_desactivada")
                    patchRefreshToken += 1
                }
            } catch {
                await MainActor.run {
                    hologramaBusy = false
                    hologramaIsActive = false
                    patchActionMessage = "No se pudo aplicar Holograma Rtx.3105: \(error.localizedDescription)"
                }
            }
        }
    }

    private func holoArmAzulPackageURL() -> URL? {
        if let url = Bundle.main.url(forResource: "HOLO ARM AZUL", withExtension: "3105"),
           FileManager.default.fileExists(atPath: url.path) { return url }
        if let url = Bundle.main.url(forResource: "HOLO ARM AZUL", withExtension: "3105", subdirectory: "ProtectedPackages"),
           FileManager.default.fileExists(atPath: url.path) { return url }
        if let resourceURL = Bundle.main.resourceURL {
            let url = resourceURL.appendingPathComponent("HOLO ARM AZUL.3105")
            if FileManager.default.fileExists(atPath: url.path) { return url }
        }
        return nil
    }

    private func toggleHoloArmAzul() {
        guard !holoAzulBusy else { return }
        guard let packageURL = holoArmAzulPackageURL() else {
            patchActionMessage = "No se encontró HOLO ARM AZUL.3105 dentro de la app."
            return
        }
        holoAzulBusy = true
        Task.detached(priority: .userInitiated) {
            do {
                let data = try PatchProjectLibrary.readPackage(at: packageURL)
                let decoded = try PatchPackageCodec.decode(data, password: nil)
                let receipt = DevicePatchService.latestReceipt(projectID: decoded.project.id)
                if let receipt {
                    try DevicePatchService.restore(receipt: receipt)
                } else {
                    // The two holo-arm packages are alternate variants; restore Rainbow first.
                    if let rainbowURL = hologramaPackageURL() {
                        let rainbowData = try PatchProjectLibrary.readPackage(at: rainbowURL)
                        let rainbowProject = try PatchPackageCodec.decode(rainbowData, password: nil).project
                        if let rainbowReceipt = DevicePatchService.latestReceipt(projectID: rainbowProject.id) {
                            try DevicePatchService.restore(receipt: rainbowReceipt)
                        }
                    }
                    _ = try DevicePatchService.apply(project: decoded.project)
                }
                await MainActor.run {
                    holoAzulIsActive = (receipt == nil)
                    if receipt == nil { hologramaIsActive = false }
                    holoAzulBusy = false
                    PantherFeedbackAudio.play(receipt == nil ? "opcion_activada" : "opcion_desactivada")
                    patchRefreshToken += 1
                }
            } catch {
                await MainActor.run {
                    holoAzulBusy = false
                    holoAzulIsActive = false
                    patchActionMessage = "No se pudo aplicar HOLO ARM AZUL.3105: \(error.localizedDescription)"
                }
            }
        }
    }


    private func holoPJAmarilloPackageURL() -> URL? {
        if let url = Bundle.main.url(forResource: "HOLO PJ AMARILLO", withExtension: "3105"),
           FileManager.default.fileExists(atPath: url.path) { return url }
        if let url = Bundle.main.url(forResource: "HOLO PJ AMARILLO", withExtension: "3105", subdirectory: "ProtectedPackages"),
           FileManager.default.fileExists(atPath: url.path) { return url }
        if let resourceURL = Bundle.main.resourceURL {
            let url = resourceURL.appendingPathComponent("HOLO PJ AMARILLO.3105")
            if FileManager.default.fileExists(atPath: url.path) { return url }
        }
        return nil
    }

    private func toggleHoloPJAmarillo() {
        guard !holoPJAmarilloBusy else { return }
        guard let packageURL = holoPJAmarilloPackageURL() else {
            patchActionMessage = "No se encontró HOLO PJ AMARILLO.3105 dentro de la app."
            return
        }
        holoPJAmarilloBusy = true
        Task.detached(priority: .userInitiated) {
            do {
                let data = try PatchProjectLibrary.readPackage(at: packageURL)
                let decoded = try PatchPackageCodec.decode(data, password: nil)
                let receipt = DevicePatchService.latestReceipt(projectID: decoded.project.id)
                if let receipt {
                    try DevicePatchService.restore(receipt: receipt)
                } else {
                    _ = try DevicePatchService.apply(project: decoded.project)
                }
                await MainActor.run {
                    holoPJAmarilloIsActive = (receipt == nil)
                    holoPJAmarilloBusy = false
                    PantherFeedbackAudio.play(receipt == nil ? "opcion_activada" : "opcion_desactivada")
                    patchRefreshToken += 1
                }
            } catch {
                await MainActor.run {
                    holoPJAmarilloBusy = false
                    holoPJAmarilloIsActive = false
                    patchActionMessage = "No se pudo aplicar HOLO PJ AMARILLO.3105: \(error.localizedDescription)"
                }
            }
        }
    }

    private func resetFFHPackageURL() -> URL? {
        if let url = Bundle.main.url(forResource: "Reset Guest", withExtension: "3105"),
           FileManager.default.fileExists(atPath: url.path) { return url }
        if let url = Bundle.main.url(
            forResource: "Reset Guest",
            withExtension: "3105",
            subdirectory: "ProtectedPackages"
        ), FileManager.default.fileExists(atPath: url.path) { return url }
        if let resourceURL = Bundle.main.resourceURL {
            let url = resourceURL.appendingPathComponent("Reset Guest.3105")
            if FileManager.default.fileExists(atPath: url.path) { return url }
        }
        return nil
    }

    private func refreshResetFFHStatus() {
        guard let url = resetFFHPackageURL(),
              let data = try? PatchProjectLibrary.readPackage(at: url),
              let summary = try? PatchPackageCodec.inspect(data) else {
            resetFFHIsActive = false
            return
        }
        resetFFHIsActive = DevicePatchService.latestReceipt(projectID: summary.packageID) != nil
    }

    private func toggleResetFFH() {
        guard !resetFFHBusy else { return }
        guard let packageURL = resetFFHPackageURL() else {
            patchActionMessage = "No se encontró Reset Guest.3105 dentro de la app."
            return
        }
        resetFFHBusy = true
        Task.detached(priority: .userInitiated) {
            do {
                let data = try PatchProjectLibrary.readPackage(at: packageURL)
                let decoded = try PatchPackageCodec.decode(data, password: nil)
                let receipt = DevicePatchService.latestReceipt(projectID: decoded.project.id)
                if let receipt {
                    try DevicePatchService.restore(receipt: receipt)
                } else {
                    _ = try DevicePatchService.apply(project: decoded.project)
                }
                await MainActor.run {
                    resetFFHIsActive = (receipt == nil)
                    resetFFHBusy = false
                    PantherFeedbackAudio.play(receipt == nil ? "opcion_activada" : "opcion_desactivada")
                    patchRefreshToken += 1
                }
            } catch {
                await MainActor.run {
                    resetFFHBusy = false
                    refreshResetFFHStatus()
                    patchActionMessage = "No se pudo completar RESET FFH: \(error.localizedDescription)"
                }
            }
        }
    }

    private func holoARPackageURL() -> URL? {
        if let url = Bundle.main.url(forResource: "HOLO AR", withExtension: "3105"),
           FileManager.default.fileExists(atPath: url.path) { return url }
        if let url = Bundle.main.url(
            forResource: "HOLO AR",
            withExtension: "3105",
            subdirectory: "ProtectedPackages"
        ), FileManager.default.fileExists(atPath: url.path) { return url }
        if let resourceURL = Bundle.main.resourceURL {
            let url = resourceURL.appendingPathComponent("HOLO AR.3105")
            if FileManager.default.fileExists(atPath: url.path) { return url }
        }
        return nil
    }

    private func refreshHoloARStatus() {
        guard let url = holoARPackageURL(),
              let data = try? PatchProjectLibrary.readPackage(at: url),
              let summary = try? PatchPackageCodec.inspect(data) else {
            holoARIsActive = false
            return
        }
        holoARIsActive = DevicePatchService.latestReceipt(projectID: summary.packageID) != nil
    }

    private func toggleHoloAR() {
        guard !holoARBusy else { return }
        guard let packageURL = holoARPackageURL() else {
            patchActionMessage = "No se encontró HOLO AR.3105 dentro de la app."
            return
        }
        holoARBusy = true
        Task.detached(priority: .userInitiated) {
            do {
                let data = try PatchProjectLibrary.readPackage(at: packageURL)
                let decoded = try PatchPackageCodec.decode(data, password: nil)
                let receipt = DevicePatchService.latestReceipt(projectID: decoded.project.id)
                if let receipt {
                    try DevicePatchService.restore(receipt: receipt)
                } else {
                    _ = try DevicePatchService.apply(project: decoded.project)
                }
                await MainActor.run {
                    holoARIsActive = (receipt == nil)
                    holoARBusy = false
                    PantherFeedbackAudio.play(receipt == nil ? "opcion_activada" : "opcion_desactivada")
                    patchRefreshToken += 1
                }
            } catch {
                await MainActor.run {
                    holoARBusy = false
                    refreshHoloARStatus()
                    patchActionMessage = "No se pudo completar HOLO AR: \(error.localizedDescription)"
                }
            }
        }
    }

    private func hologramaExtraPackageURL() -> URL? {
        if let url = Bundle.main.url(forResource: "HOLOGRAMA", withExtension: "3105"),
           FileManager.default.fileExists(atPath: url.path) { return url }
        if let url = Bundle.main.url(
            forResource: "HOLOGRAMA",
            withExtension: "3105",
            subdirectory: "ProtectedPackages"
        ), FileManager.default.fileExists(atPath: url.path) { return url }
        if let resourceURL = Bundle.main.resourceURL {
            let url = resourceURL.appendingPathComponent("HOLOGRAMA.3105")
            if FileManager.default.fileExists(atPath: url.path) { return url }
        }
        return nil
    }

    private func refreshHologramaExtraStatus() {
        guard let url = hologramaExtraPackageURL(),
              let data = try? PatchProjectLibrary.readPackage(at: url),
              let summary = try? PatchPackageCodec.inspect(data) else {
            hologramaExtraIsActive = false
            return
        }
        hologramaExtraIsActive = DevicePatchService.latestReceipt(projectID: summary.packageID) != nil
    }

    private func toggleHologramaExtra() {
        guard !hologramaExtraBusy else { return }
        guard let packageURL = hologramaExtraPackageURL() else {
            patchActionMessage = "No se encontró HOLOGRAMA.3105 dentro de la app."
            return
        }
        hologramaExtraBusy = true
        Task.detached(priority: .userInitiated) {
            do {
                let data = try PatchProjectLibrary.readPackage(at: packageURL)
                let decoded = try PatchPackageCodec.decode(data, password: nil)
                let receipt = DevicePatchService.latestReceipt(projectID: decoded.project.id)
                if let receipt {
                    try DevicePatchService.restore(receipt: receipt)
                } else {
                    _ = try DevicePatchService.apply(project: decoded.project)
                }
                await MainActor.run {
                    hologramaExtraIsActive = (receipt == nil)
                    hologramaExtraBusy = false
                    PantherFeedbackAudio.play(receipt == nil ? "opcion_activada" : "opcion_desactivada")
                    patchRefreshToken += 1
                }
            } catch {
                await MainActor.run {
                    hologramaExtraBusy = false
                    refreshHologramaExtraStatus()
                    patchActionMessage = "No se pudo completar HOLOGRAMA: \(error.localizedDescription)"
                }
            }
        }
    }

    private func avatarSlot(_ name: String, displayName: String? = nil) -> some View {
        let item = orderedAvatarItems.first {
            ($0.project?.name ?? $0.packageURL.deletingPathExtension().lastPathComponent)
                .caseInsensitiveCompare(name) == .orderedSame
        }
        let active = item.map { DevicePatchService.latestReceipt(projectID: $0.id) != nil } ?? false
        let busy = item.map { busyPatchIDs.contains($0.id) } ?? false
        return Button {
            if let item = item { togglePatch(item) }
            else { patchActionMessage = "El paquete \(name).3105 todavía no está disponible." }
        } label: {
            HStack(spacing: 14) {
                Image(systemName: "scope")
                    .font(.system(size: 25, weight: .medium)).foregroundStyle(externalAccent)
                    .frame(width: 40)
                Text((displayName ?? name).uppercased())
                    .font(.system(size: 16, weight: .medium, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1).minimumScaleFactor(0.78)
                Spacer(minLength: 4)
                if busy {
                    ProgressView().tint(.white).frame(width: 54)
                } else {
                    ZStack(alignment: active ? .trailing : .leading) {
                        Capsule().fill(Color(white: 0.24)).frame(width: 66, height: 40)
                        Circle().fill(.white).frame(width: 32, height: 32).padding(.horizontal, 4)
                    }
                    .frame(width: 66, height: 40)
                }
            }
            .padding(.horizontal, 16)
            .frame(maxWidth: .infinity).frame(height: 78)
            .background(Color(red: 0.055, green: 0.065, blue: 0.085).opacity(0.88), in: RoundedRectangle(cornerRadius: 25))
            .overlay(RoundedRectangle(cornerRadius: 25).stroke(externalAccent.opacity(0.48), lineWidth: 1))
            .shadow(color: .black.opacity(0.22), radius: 10, y: 4)
        }
        .buttonStyle(.plain)
        .disabled(busy)
    }

    private func importBundledPatchesIfNeeded() {
        PantherBundledPackages.installIfNeeded()
        store.reload()
    }

    private func togglePatch(_ item: PatchLibraryItem) {
        guard !busyPatchIDs.contains(item.id) else { return }
        let currentReceipt = DevicePatchService.latestReceipt(projectID: item.id)
        guard currentReceipt != nil || item.project != nil else {
            patchActionMessage = "El paquete no contiene un proyecto válido para aplicar."
            return
        }
        busyPatchIDs.insert(item.id)
        Task.detached(priority: .userInitiated) {
            do {
                if let receipt = currentReceipt {
                    try DevicePatchService.restore(receipt: receipt)
                } else if let project = item.project {
                    let prepared = item.summary.schemaVersion >= 2
                        ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                        : project
                    _ = try DevicePatchService.apply(project: prepared)
                }
                await MainActor.run {
                    PantherFeedbackAudio.play(currentReceipt != nil ? "opcion_desactivada" : "opcion_activada")
                    store.reload()
                    busyPatchIDs.remove(item.id)
                    patchRefreshToken += 1
                }
            } catch {
                await MainActor.run {
                    busyPatchIDs.remove(item.id)
                    patchActionMessage = "No se pudo completar la operación: \(error.localizedDescription)"
                }
            }
        }
    }

    private func consumeExternalImport() {
        guard let request = draftCoordinator.importRequest else { return }
        draftCoordinator.clearImport()
        store.importPackage(from: request.source)
    }

    @ViewBuilder
    private func itemRow(_ item: PatchLibraryItem) -> some View {
        if item.isLocked {
            Button { store.requestUnlock(for: item) } label: {
                PatchProjectRow(item: item, language: language)
            }
            .buttonStyle(.plain)
        } else {
            NavigationLink {
                PatchProjectDetailView(store: store, projectID: item.id)
            } label: {
                PatchProjectRow(item: item, language: language)
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "shippingbox")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(AppTheme.accent)
            Text(language.text("patch.empty_title"))
                .font(.headline)
            Text(language.text("patch.empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button(language.text("patch.new")) { showCreate = true }
                .buttonStyle(.bordered)
                .controlSize(.large)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }

    private var searchEmptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(.secondary)
            Text(language.text("patch.search_empty"))
                .font(.headline)
            Text(language.text("patch.search_empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }
}

private struct PatchProjectRow: View {
    let item: PatchLibraryItem
    let language: AppLanguage

    var body: some View {
        HStack(spacing: 12) {
            AppRowIcon(systemName: item.isLocked ? "lock.doc.fill" : "shippingbox.fill")
            VStack(alignment: .leading, spacing: 3) {
                Text(item.project?.name ?? language.text("patch.locked_project"))
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                Text(item.isLocked
                     ? language.text("patch.tap_to_unlock")
                     : language.text(
                        item.summary.schemaVersion >= 2 ? "patch.workspace_items_count" : "patch.rules_count",
                        Int64((item.project?.rules.count ?? 0) + (item.project?.directories.count ?? 0))
                     ))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if item.summary.isPasswordProtected {
                Image(systemName: "key.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .accessibilityLabel(language.text("patch.password_protected"))
            }
        }
        .padding(.vertical, 4)
    }
}

private struct PatchUnlockView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(language.text("patch.password"), text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in
                            store.clearUnlockError()
                        }
                    if let errorKey = store.unlockErrorKey {
                        Text(language.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                } footer: {
                    Text(language.text("patch.password_once_message"))
                }
            }
            .navigationTitle(language.text("patch.unlock"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("patch.unlock"), action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

private struct PatchProjectDetailView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    let projectID: UUID
    @State private var showEditor = false
    @State private var editingRule: PatchRule?
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?
    @State private var shareRequest: PatchShareRequest?

    private var item: PatchLibraryItem? {
        store.items.first(where: { $0.id == projectID })
    }

    private var receipt: PatchTransactionReceipt? {
        DevicePatchService.latestReceipt(projectID: projectID)
    }

    private var isWorkspaceProject: Bool {
        (item?.summary.schemaVersion ?? 1) >= 2
    }

    var body: some View {
        List {
            if let item, let project = item.project {
                if isWorkspaceProject {
                    Section {
                        ForEach(project.allBundleIdentifiers, id: \.self) { bundleID in
                            Label {
                                Text(bundleID)
                                    .font(.subheadline.monospaced())
                            } icon: {
                                Image(systemName: "app.dashed")
                                    .foregroundStyle(AppTheme.accent)
                            }
                        }
                        LabeledContent(language.text("patch.files")) {
                            Text("\(project.rules.count)")
                        }
                        LabeledContent(language.text("patch.folders")) {
                            Text("\(project.directories.count)")
                        }
                        if let workspaceURL = item.workspaceURL {
                            NavigationLink {
                                FileBrowserView(
                                    containerPath: workspaceURL.path,
                                    title: project.name,
                                    bundleID: nil
                                )
                            } label: {
                                Label(
                                    language.text("patch.open_workspace"),
                                    systemImage: "folder"
                                )
                            }
                        }
                    } header: {
                        Text(language.text("patch.workspace"))
                    } footer: {
                        Text(language.text("patch.workspace_detail_footer"))
                    }
                } else {
                    Section {
                        ForEach(project.rules) { rule in
                            Button {
                                editingRule = rule
                            } label: {
                                HStack(spacing: 10) {
                                    ruleSummary(rule)
                                    Spacer(minLength: 8)
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(.tertiary)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityHint(language.text("patch.edit_rule_hint"))
                        }
                    } header: {
                        Text(language.text("patch.rules"))
                    } footer: {
                        Text(language.text("patch.legacy_footer"))
                    }
                }

                Section(language.text("patch.password")) {
                    HStack(spacing: 12) {
                        Image(systemName: item.summary.isPasswordProtected ? "lock.fill" : "lock.open")
                            .foregroundStyle(AppTheme.accent)
                            .frame(width: 24)
                        Text(language.text(item.summary.isPasswordProtected
                            ? "patch.password_locked"
                            : "patch.no_password"))
                            .font(.subheadline)
                    }
                }

                Section {
                    Button {
                        showApplyConfirmation = true
                    } label: {
                        actionLabel("patch.apply", systemImage: "checkmark.shield.fill")
                    }
                    .disabled(isWorking)

                    if receipt != nil {
                        Button(role: .destructive) {
                            showRestoreConfirmation = true
                        } label: {
                            actionLabel("patch.restore", systemImage: "arrow.uturn.backward.circle")
                        }
                        .disabled(isWorking)
                    }

                    Button(action: prepareExport) {
                        actionLabel("patch.export", systemImage: "square.and.arrow.up")
                    }
                    .disabled(isWorking)
                } footer: {
                    Text(language.text("patch.apply_footer"))
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(item?.project?.name ?? language.text("patch.title"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if isWorking {
                    ProgressView()
                } else if !isWorkspaceProject {
                    Button(language.text("patch.edit")) { showEditor = true }
                        .disabled(item?.project == nil)
                }
            }
        }
        .sheet(isPresented: $showEditor) {
            if let item, let project = item.project {
                PatchProjectEditorView(
                    existingProject: project,
                    passwordIsProtected: item.summary.isPasswordProtected
                ) { updatedProject, _ in
                    store.update(project: updatedProject)
                }
            }
        }
        .sheet(item: $editingRule) { rule in
            PatchRuleEditorView(rule: rule) { updatedRule in
                updateRule(updatedRule)
            }
        }
        .confirmationDialog(
            language.text("patch.apply_confirm_title"),
            isPresented: $showApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.apply")) { apply() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.apply_confirm_message"))
        }
        .confirmationDialog(
            language.text("patch.restore_confirm_title"),
            isPresented: $showRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.restore"), role: .destructive) { restore() }
            Button(language.text("common.cancel"), role: .cancel) {}
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
        .sheet(item: $shareRequest) { request in
            PatchActivityView(items: [request.url])
                .ignoresSafeArea()
        }
    }

    private func actionLabel(_ key: String, systemImage: String) -> some View {
        Label(language.text(key), systemImage: systemImage)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func ruleSummary(_ rule: PatchRule) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(rule.bundleID)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
            Text(rule.relativePath)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
                .lineLimit(2)
            Label(rule.replacementFilename, systemImage: "arrow.triangle.2.circlepath")
                .font(.caption)
                .foregroundStyle(AppTheme.accent)
        }
        .padding(.vertical, 3)
    }

    private func updateRule(_ updatedRule: PatchRule) {
        guard var project = item?.project,
              let index = project.rules.firstIndex(where: { $0.id == updatedRule.id }) else {
            return
        }
        project.rules[index] = updatedRule
        project.updatedAt = Date()
        do {
            try PatchPackageCodec.validate(project)
            store.update(project: project)
        } catch let error as PatchPackageError {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: error.localizationKey,
                messageArgument: error.localizationArgument
            )
        } catch {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.invalid_project"
            )
        }
    }

    private func apply() {
        guard let item, let baseProject = item.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func prepareExport() {
        guard let item else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                if item.summary.schemaVersion >= 2 {
                    _ = try PatchProjectLibrary.synchronizeWorkspace(item: item)
                }
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    shareRequest = PatchShareRequest(url: item.packageURL)
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.invalid_project"
                    )
                }
            }
        }
    }

    private func restore() {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }
}

private struct PatchShareRequest: Identifiable {
    let id = UUID()
    let url: URL
}

private struct PatchActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(
        _ uiViewController: UIActivityViewController,
        context: Context
    ) {}
}


private struct ExternalNoBounceModifier: ViewModifier {
    func body(content: Content) -> some View {
        content.background(ExternalScrollBounceDisabler())
    }
}

/// Disables only the rubber-band bounce of the containing native scroll view.
/// Scrolling through the content remains enabled in both directions within bounds.
private struct ExternalScrollBounceDisabler: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        view.backgroundColor = .clear
        view.isUserInteractionEnabled = false
        DispatchQueue.main.async {
            disableBounce(in: view)
        }
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        DispatchQueue.main.async {
            disableBounce(in: uiView)
        }
    }

    private func disableBounce(in view: UIView) {
        var ancestor: UIView? = view
        while let current = ancestor {
            if let scrollView = current as? UIScrollView {
                scrollView.bounces = false
                scrollView.alwaysBounceVertical = false
                scrollView.alwaysBounceHorizontal = false
                return
            }
            ancestor = current.superview
        }
    }
}
