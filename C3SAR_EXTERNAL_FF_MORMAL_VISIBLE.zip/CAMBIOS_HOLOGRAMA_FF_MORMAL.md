# Integración HOLOGRAMA en FF MORMAL

- Se añadió `HOLOGRAMA` como segunda opción debajo de `HOLO AR` dentro de `FF MORMAL`.
- La opción tiene estado, indicador de carga y acción independiente de activar/restaurar mediante `DevicePatchService`, igual que las opciones existentes.
- Se convirtió `Holograma.3105` de esquema 9 a esquema 2, conservando el ID del paquete, la clave pública y el payload autenticado. El contenido cifrado se volvió a sellar con AAD de esquema 2.
- Se registró `ProtectedPackages/HOLOGRAMA.3105` como recurso del proyecto Xcode.

## Validación realizada

- Se autenticó y descifró el paquete original con AES-GCM.
- Se volvió a cifrar con el formato de esquema 2 y se verificó la autenticidad del payload resultante.
- Se verificó que el paquete contiene el proyecto `Holograma`, el identificador `com.dts.freefiremax`, cinco directorios y una regla.
- No se pudo ejecutar una compilación de Xcode ni probar la aplicación en un iPhone en este entorno. La activación real depende de que el destino y los permisos estén disponibles en el dispositivo.
